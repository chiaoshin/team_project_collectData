<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDangerAreaTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('danger_area', function (Blueprint $table) {
            $table->id('da_id')->comment('危險區域編號');
            $table->string('area_n')->comment('危險海域名稱');
            $table->text('range')->comment('區域範圍');
            $table->text('limit')->comment('限制活動');
            $table->double('lat')->comment("緯度");
            $table->double('lng')->comment("經度");
            $table->string('around')->nullable()->comment('周遭潛點');
            $table->string('url')->nullable()->comment("連結");
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('danger_area');
    }
}
